﻿namespace OtobusBiletSimulasyonu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.OtobusSecme = new System.Windows.Forms.Label();
            this.cmbOtoSec = new System.Windows.Forms.ComboBox();
            this.lblKalkisİli = new System.Windows.Forms.Label();
            this.cmbKalkisİli = new System.Windows.Forms.ComboBox();
            this.cmbvarisİli = new System.Windows.Forms.ComboBox();
            this.lblVarisİli = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtmpsaat = new System.Windows.Forms.DateTimePicker();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnSeferiKaydet = new System.Windows.Forms.Button();
            this.groupBox1Sehirsec = new System.Windows.Forms.GroupBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.rezerveEtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnsil = new System.Windows.Forms.Button();
            this.BtnKoltukDegistir = new System.Windows.Forms.Button();
            this.cmbilekoltuksec = new System.Windows.Forms.ComboBox();
            this.chkyildiz = new System.Windows.Forms.CheckBox();
            this.btncmbileseferekle = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbdeneme = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1Sehirsec.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // OtobusSecme
            // 
            this.OtobusSecme.AutoSize = true;
            this.OtobusSecme.Location = new System.Drawing.Point(492, 41);
            this.OtobusSecme.Name = "OtobusSecme";
            this.OtobusSecme.Size = new System.Drawing.Size(152, 16);
            this.OtobusSecme.TabIndex = 0;
            this.OtobusSecme.Text = "Otobus numarası seçiniz";
            // 
            // cmbOtoSec
            // 
            this.cmbOtoSec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOtoSec.FormattingEnabled = true;
            this.cmbOtoSec.Items.AddRange(new object[] {
            "Pamukkale-01",
            "Kamil Koç-02",
            "Artvin Lüks-03",
            "yalova seyahat-04",
            "Mardin Seyahat-05",
            "Kontur-06",
            "Öz Sivas-07",
            "Nilüfer-08",
            "Artvin-09",
            "Uludağ turizm-10"});
            this.cmbOtoSec.Location = new System.Drawing.Point(674, 33);
            this.cmbOtoSec.Name = "cmbOtoSec";
            this.cmbOtoSec.Size = new System.Drawing.Size(121, 24);
            this.cmbOtoSec.TabIndex = 1;
            this.cmbOtoSec.SelectedIndexChanged += new System.EventHandler(this.cmbOtoSec_SelectedIndexChanged);
            // 
            // lblKalkisİli
            // 
            this.lblKalkisİli.AutoSize = true;
            this.lblKalkisİli.Location = new System.Drawing.Point(10, 29);
            this.lblKalkisİli.Name = "lblKalkisİli";
            this.lblKalkisİli.Size = new System.Drawing.Size(55, 16);
            this.lblKalkisİli.TabIndex = 2;
            this.lblKalkisİli.Text = "Kalkış İli";
            // 
            // cmbKalkisİli
            // 
            this.cmbKalkisİli.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKalkisİli.FormattingEnabled = true;
            this.cmbKalkisİli.Items.AddRange(new object[] {
            " Adana",
            " Adıyaman",
            " Afyonkarahisar",
            " Ağrı",
            " Aksaray",
            " Amasya",
            " Ankara",
            " Antalya",
            " Ardahan",
            " Artvin",
            " Aydın",
            " Balıkesir",
            " Bartın",
            " Batman",
            " Bayburt",
            " Bilecik",
            " Bingöl",
            " Bitlis",
            " Bolu",
            " Burdur",
            " Bursa",
            " Çanakkale",
            " Çankırı",
            " Çorum",
            " Denizli",
            " Diyarbakır",
            " Düzce",
            " Edirne",
            " Elazığ",
            " Erzincan",
            " Erzurum",
            " Eskişehir",
            " Gaziantep",
            " Giresun",
            " Gümüşhane",
            " Hakkâri",
            " Hatay",
            " Iğdır",
            " Isparta",
            " İstanbul",
            " İzmir",
            " Kahramanmaraş",
            " Karabük",
            " Karaman",
            " Kars",
            " Kastamonu",
            " Kayseri",
            " Kilis",
            " Kırıkkale",
            " Kırklareli",
            " Kırşehir",
            " Kocaeli",
            " Konya",
            " Kütahya",
            " Malatya",
            " Manisa",
            " Mardin",
            " Mersin",
            " Muğla",
            " Muş",
            " Nevşehir",
            " Niğde",
            " Ordu",
            " Osmaniye",
            " Rize",
            " Sakarya",
            " Samsun",
            " Şanlıurfa",
            " Siirt",
            " Sinop",
            " Sivas",
            " Şırnak",
            " Tekirdağ",
            " Tokat",
            " Trabzon",
            " Tunceli",
            " Uşak",
            " Van",
            " Yalova",
            " Yozgat",
            " Zonguldak"});
            this.cmbKalkisİli.Location = new System.Drawing.Point(192, 21);
            this.cmbKalkisİli.Name = "cmbKalkisİli";
            this.cmbKalkisİli.Size = new System.Drawing.Size(121, 24);
            this.cmbKalkisİli.TabIndex = 3;
            // 
            // cmbvarisİli
            // 
            this.cmbvarisİli.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbvarisİli.FormattingEnabled = true;
            this.cmbvarisİli.Items.AddRange(new object[] {
            " Adana",
            " Adıyaman",
            " Afyonkarahisar",
            " Ağrı",
            " Aksaray",
            " Amasya",
            " Ankara",
            " Antalya",
            " Ardahan",
            " Artvin",
            " Aydın",
            " Balıkesir",
            " Bartın",
            " Batman",
            " Bayburt",
            " Bilecik",
            " Bingöl",
            " Bitlis",
            " Bolu",
            " Burdur",
            " Bursa",
            " Çanakkale",
            " Çankırı",
            " Çorum",
            " Denizli",
            " Diyarbakır",
            " Düzce",
            " Edirne",
            " Elazığ",
            " Erzincan",
            " Erzurum",
            " Eskişehir",
            " Gaziantep",
            " Giresun",
            " Gümüşhane",
            " Hakkâri",
            " Hatay",
            " Iğdır",
            " Isparta",
            " İstanbul",
            " İzmir",
            " Kahramanmaraş",
            " Karabük",
            " Karaman",
            " Kars",
            " Kastamonu",
            " Kayseri",
            " Kilis",
            " Kırıkkale",
            " Kırklareli",
            " Kırşehir",
            " Kocaeli",
            " Konya",
            " Kütahya",
            " Malatya",
            " Manisa",
            " Mardin",
            " Mersin",
            " Muğla",
            " Muş",
            " Nevşehir",
            " Niğde",
            " Ordu",
            " Osmaniye",
            " Rize",
            " Sakarya",
            " Samsun",
            " Şanlıurfa",
            " Siirt",
            " Sinop",
            " Sivas",
            " Şırnak",
            " Tekirdağ",
            " Tokat",
            " Trabzon",
            " Tunceli",
            " Uşak",
            " Van",
            " Yalova",
            " Yozgat",
            " Zonguldak"});
            this.cmbvarisİli.Location = new System.Drawing.Point(192, 87);
            this.cmbvarisİli.Name = "cmbvarisİli";
            this.cmbvarisİli.Size = new System.Drawing.Size(121, 24);
            this.cmbvarisİli.TabIndex = 4;
            // 
            // lblVarisİli
            // 
            this.lblVarisİli.AutoSize = true;
            this.lblVarisİli.Location = new System.Drawing.Point(10, 87);
            this.lblVarisİli.Name = "lblVarisİli";
            this.lblVarisİli.Size = new System.Drawing.Size(53, 16);
            this.lblVarisİli.TabIndex = 5;
            this.lblVarisİli.Text = "Varış ili ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(480, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Tarih Seç";
            // 
            // dtmpsaat
            // 
            this.dtmpsaat.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtmpsaat.Location = new System.Drawing.Point(662, 252);
            this.dtmpsaat.Name = "dtmpsaat";
            this.dtmpsaat.Size = new System.Drawing.Size(143, 22);
            this.dtmpsaat.TabIndex = 7;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(823, 12);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(642, 516);
            this.listView1.TabIndex = 8;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "YOLCU";
            this.columnHeader1.Width = 120;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Telefon";
            this.columnHeader2.Width = 107;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Cinsiyet";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Kalkış İli";
            this.columnHeader4.Width = 76;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Varış İli";
            this.columnHeader5.Width = 73;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Koltuk No";
            this.columnHeader6.Width = 56;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Tarih";
            this.columnHeader7.Width = 71;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Otobüs No";
            // 
            // btnSeferiKaydet
            // 
            this.btnSeferiKaydet.Location = new System.Drawing.Point(1317, 582);
            this.btnSeferiKaydet.Name = "btnSeferiKaydet";
            this.btnSeferiKaydet.Size = new System.Drawing.Size(93, 25);
            this.btnSeferiKaydet.TabIndex = 9;
            this.btnSeferiKaydet.Text = "KAYDET";
            this.btnSeferiKaydet.UseVisualStyleBackColor = true;
            this.btnSeferiKaydet.Visible = false;
            // 
            // groupBox1Sehirsec
            // 
            this.groupBox1Sehirsec.Controls.Add(this.cmbKalkisİli);
            this.groupBox1Sehirsec.Controls.Add(this.lblKalkisİli);
            this.groupBox1Sehirsec.Controls.Add(this.cmbvarisİli);
            this.groupBox1Sehirsec.Controls.Add(this.lblVarisİli);
            this.groupBox1Sehirsec.Location = new System.Drawing.Point(459, 83);
            this.groupBox1Sehirsec.Name = "groupBox1Sehirsec";
            this.groupBox1Sehirsec.Size = new System.Drawing.Size(346, 148);
            this.groupBox1Sehirsec.TabIndex = 10;
            this.groupBox1Sehirsec.TabStop = false;
            this.groupBox1Sehirsec.Text = "Şehir Seç";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rezerveEtToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(148, 28);
            // 
            // rezerveEtToolStripMenuItem
            // 
            this.rezerveEtToolStripMenuItem.Name = "rezerveEtToolStripMenuItem";
            this.rezerveEtToolStripMenuItem.Size = new System.Drawing.Size(147, 24);
            this.rezerveEtToolStripMenuItem.Text = "Rezerve Et";
            this.rezerveEtToolStripMenuItem.Click += new System.EventHandler(this.rezerveEtToolStripMenuItem_Click);
            // 
            // btnsil
            // 
            this.btnsil.BackColor = System.Drawing.Color.Red;
            this.btnsil.Location = new System.Drawing.Point(662, 356);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(121, 36);
            this.btnsil.TabIndex = 11;
            this.btnsil.Text = "SEFER SİL";
            this.btnsil.UseVisualStyleBackColor = false;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // BtnKoltukDegistir
            // 
            this.BtnKoltukDegistir.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BtnKoltukDegistir.Location = new System.Drawing.Point(561, 409);
            this.BtnKoltukDegistir.Name = "BtnKoltukDegistir";
            this.BtnKoltukDegistir.Size = new System.Drawing.Size(159, 41);
            this.BtnKoltukDegistir.TabIndex = 12;
            this.BtnKoltukDegistir.Text = "KOLTUK DEĞİŞTİR";
            this.BtnKoltukDegistir.UseVisualStyleBackColor = false;
            this.BtnKoltukDegistir.Click += new System.EventHandler(this.BtnKoltukDegistir_Click);
            // 
            // cmbilekoltuksec
            // 
            this.cmbilekoltuksec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbilekoltuksec.Enabled = false;
            this.cmbilekoltuksec.FormattingEnabled = true;
            this.cmbilekoltuksec.Items.AddRange(new object[] {
            "1  ",
            "2  ",
            "3  ",
            "4  ",
            "5  ",
            "6  ",
            "7  ",
            "8  ",
            "9  ",
            "10  ",
            "11  ",
            "12  ",
            "13  ",
            "14  ",
            "15  ",
            "16  ",
            "17  ",
            "18  ",
            "19  ",
            "20  ",
            "21  ",
            "22  ",
            "23  ",
            "24  ",
            "25  ",
            "26  ",
            "27  ",
            "28  ",
            "29  ",
            "30  ",
            "31  ",
            "32  ",
            "33  ",
            "34  ",
            "35  ",
            "36  ",
            "37  ",
            "38  ",
            "39  ",
            "40  ",
            "41  ",
            "42  "});
            this.cmbilekoltuksec.Location = new System.Drawing.Point(1436, 583);
            this.cmbilekoltuksec.Name = "cmbilekoltuksec";
            this.cmbilekoltuksec.Size = new System.Drawing.Size(42, 24);
            this.cmbilekoltuksec.TabIndex = 13;
            this.cmbilekoltuksec.Visible = false;
            this.cmbilekoltuksec.SelectedIndexChanged += new System.EventHandler(this.cmbilekoltuksec_SelectedIndexChanged);
            // 
            // chkyildiz
            // 
            this.chkyildiz.AutoSize = true;
            this.chkyildiz.Location = new System.Drawing.Point(1413, 534);
            this.chkyildiz.Name = "chkyildiz";
            this.chkyildiz.Size = new System.Drawing.Size(34, 20);
            this.chkyildiz.TabIndex = 15;
            this.chkyildiz.Text = "*";
            this.chkyildiz.UseVisualStyleBackColor = true;
            // 
            // btncmbileseferekle
            // 
            this.btncmbileseferekle.BackColor = System.Drawing.Color.SeaGreen;
            this.btncmbileseferekle.Location = new System.Drawing.Point(511, 356);
            this.btncmbileseferekle.Name = "btncmbileseferekle";
            this.btncmbileseferekle.Size = new System.Drawing.Size(118, 36);
            this.btncmbileseferekle.TabIndex = 16;
            this.btncmbileseferekle.Text = "SEFER EKLE";
            this.btncmbileseferekle.UseVisualStyleBackColor = false;
            this.btncmbileseferekle.Click += new System.EventHandler(this.btncmbileseferekle_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(479, 299);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "Koltuk Numara";
            // 
            // cmbdeneme
            // 
            this.cmbdeneme.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbdeneme.FormattingEnabled = true;
            this.cmbdeneme.Items.AddRange(new object[] {
            "1  ",
            "2  ",
            "3  ",
            "4  ",
            "5  ",
            "6  ",
            "7  ",
            "8  ",
            "9  ",
            "10  ",
            "11  ",
            "12  ",
            "13  ",
            "14  ",
            "15  ",
            "16  ",
            "17  ",
            "18  ",
            "19  ",
            "20  ",
            "21  ",
            "22  ",
            "23  ",
            "24  ",
            "25  ",
            "26  ",
            "27  ",
            "28  ",
            "29  ",
            "30  ",
            "31  ",
            "32  ",
            "33  ",
            "34  ",
            "35  ",
            "36  ",
            "37  ",
            "38  ",
            "39  ",
            "40  ",
            "41  ",
            "42  "});
            this.cmbdeneme.Location = new System.Drawing.Point(646, 299);
            this.cmbdeneme.Name = "cmbdeneme";
            this.cmbdeneme.Size = new System.Drawing.Size(159, 24);
            this.cmbdeneme.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Yellow;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(573, 18);
            this.label3.TabIndex = 19;
            this.label3.Text = "Not : Koltuklar üzerine sağ tıklayıp rezerve et butonu sizi kayıt formuna yönlend" +
    "ireceltir.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1490, 619);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbdeneme);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btncmbileseferekle);
            this.Controls.Add(this.chkyildiz);
            this.Controls.Add(this.cmbilekoltuksec);
            this.Controls.Add(this.BtnKoltukDegistir);
            this.Controls.Add(this.btnsil);
            this.Controls.Add(this.groupBox1Sehirsec);
            this.Controls.Add(this.btnSeferiKaydet);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.dtmpsaat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbOtoSec);
            this.Controls.Add(this.OtobusSecme);
            this.Name = "Form1";
            this.Text = "Form1";
           // this.Load += new System.EventHandler(this.Form1_Load_1);
            this.groupBox1Sehirsec.ResumeLayout(false);
            this.groupBox1Sehirsec.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OtobusSecme;
        private System.Windows.Forms.ComboBox cmbOtoSec;
        private System.Windows.Forms.Label lblKalkisİli;
        private System.Windows.Forms.ComboBox cmbKalkisİli;
        private System.Windows.Forms.ComboBox cmbvarisİli;
        private System.Windows.Forms.Label lblVarisİli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtmpsaat;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnSeferiKaydet;
        private System.Windows.Forms.GroupBox groupBox1Sehirsec;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
       
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem rezerveEtToolStripMenuItem;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.Button BtnKoltukDegistir;
        private System.Windows.Forms.ComboBox cmbilekoltuksec;
        private System.Windows.Forms.CheckBox chkyildiz;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.Button btncmbileseferekle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbdeneme;
        private System.Windows.Forms.Label label3;
    }
}

