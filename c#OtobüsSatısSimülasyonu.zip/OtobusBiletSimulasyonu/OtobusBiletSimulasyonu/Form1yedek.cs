﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.Json;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace OtobusBiletSimulasyonu

{
    /* public class Yolcu  // Birinci sınıf
     {
         public string AdSoyad { get; set; }
         public string Telefon { get; set; }
         public int SeferNo { get; set; }
         public int KoltukNo { get; set; }
         public string Cinsiyet { get; set; }
     }
                                                     //sınıfları olusturdum
     public class Sefer  // İkinci sınıf
     {
         public int SeferNo { get; set; }
         public string KalkisSehri { get; set; }
         public string VarisSehri { get; set; }
         public DateTime KalkisSaati { get; set; }
     }*/
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Load += new EventHandler(Form1_Load); // Form yüklenirken tetiklenecek
        }
        private void SaveDataToJson()
        {
            List<Dictionary<string, string>> passengers = new List<Dictionary<string, string>>();

            foreach (ListViewItem item in listView1.Items)
            {
                var passengerData = new Dictionary<string, string>
        {
            { "AdSoyad", item.SubItems[0].Text },
            { "Telefon", item.SubItems[1].Text },
            { "Cinsiyet", item.SubItems[2].Text },
            { "Kalkisİli", item.SubItems[3].Text },
            { "Varisİli", item.SubItems[4].Text },
            {  "seciminiz"  , item.SubItems[4].Text } ,      
            { "KoltukNo", item.SubItems[5].Text },
            { "Saat", item.SubItems[6].Text } ,          
            { "OtobusNo", item.SubItems[7].Text }  // OtobusNo sütunu eklendi
        };
                passengers.Add(passengerData);
            }

            string json = JsonSerializer.Serialize(passengers, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText("passengers.json", json);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            LoadDataFromJson();
            //btnTest.Visible = true;


        }
        private void LoadDataFromJson()
        {
            string filePath = "passengers.json";

            // Dosya varsa yükle
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);

                // JSON'u deserialize et
                var passengers = JsonSerializer.Deserialize<List<Dictionary<string, string>>>(json);

                // ListView'e ekle
                if (passengers != null)
                {
                    foreach (var passenger in passengers)
                    {
                        ListViewItem lvi = new ListViewItem(passenger["AdSoyad"]);
                        lvi.SubItems.Add(passenger["Telefon"]);
                        lvi.SubItems.Add(passenger["Cinsiyet"]);
                        lvi.SubItems.Add(passenger["Kalkisİli"]);
                        lvi.SubItems.Add(passenger["Varisİli"]);
                        lvi.SubItems.Add(passenger["KoltukNo"]);
                        lvi.SubItems.Add(passenger["Saat"]);
                        lvi.SubItems.Add(passenger.ContainsKey("OtobusNo") ? passenger["OtobusNo"] : "Bilinmiyor");

                        //lvi.SubItems.Add(passenger["OtobusNo"]); // OtobusNo sütununu ekledik
                        listView1.Items.Add(lvi);

                        // Koltuğun rengini geri yükle
                        foreach (Control ctrl in this.Controls)
                        {
                            if (ctrl is Button && ctrl.Text == passenger["KoltukNo"])
                            {
                                ctrl.BackColor = passenger["Cinsiyet"] == "KADIN" ? Color.Pink : Color.Blue;
                                break;
                            }
                        }
                    }
                }
            }
        }


        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) return;

            ListViewItem selectedItem = listView1.SelectedItems[0];

            // Eğer * seçiliyse, yeni form aç
            if (selectedItem.Text == "*")
            {
                // ListView'deki tüm yolcu bilgilerini topla
                List<ListViewItem> allPassengers = new List<ListViewItem>();
                foreach (ListViewItem item in listView1.Items)
                {
                    if (item.Text != "*") // * öğesi hariç
                        allPassengers.Add(item);
                }

                // Yeni form aç ve verileri gönder
                //Form2 form2 = new Form2();
                // form2.LoadPassengerData(allPassengers); // Verileri gönder
                //form2.ShowDialog(); // Formu göster
            }
        }


         private void cmbOtoSec_SelectedIndexChanged(object sender, EventArgs e)
           

           //this.cmbOtoSec.SelectedIndexChanged += new System.EventHandler(this.cmbOtoSec_SelectedIndexChanged);
           {
            //btnTest.Visible = true;
            switch (cmbOtoSec.Text)
            {
                case "Pamukkale-01":
                    KoltukDoldur(8, true);
                    break;
                case "Kamil Koç-02":
                    KoltukDoldur(8, true);
                    break;
                case "Artvin Lüks-03":
                    KoltukDoldur(8, true);
                    break;
                case "yalova seyahat-04":
                    KoltukDoldur(8, true);
                    break;
                case "Mardin Seyahat-05":
                    KoltukDoldur(8, true);
                    break;
                case "Kontur-06":
                    KoltukDoldur(8, true);
                    break;
                case "Öz Sivas-07":
                    KoltukDoldur(8, true);
                    break;
                case "Nilüfer-08":
                    KoltukDoldur(8, true);
                    break;
                case "Artvin-09":
                    KoltukDoldur(8, true);
                    break;
                case "Uludağ turizm-10":
                    KoltukDoldur(8, true);
                    break;

            }




            void KoltukDoldur(int sira, bool arkaBesliMi)

            {
                foreach (Control ctrl in this.Controls)
                {
                    if (ctrl is Button)
                    {
                        Button btn = ctrl as Button;
                        if (btn.Text == "Kaydet" || btn.Text == "SEFER SİL" || btn.Text == "KOLTUK DEĞİŞTİR" || btn.Text=="SEFER EKLE")
                        {
                            continue;

                        }
                        else
                        {
                            this.Controls.Remove(ctrl);
                        }

                    }
                    int koltukNo = 1;
                    int toplamKoltukSayisi = 42;
                    int siraSayisi = toplamKoltukSayisi / 4; // Her satırda 6 koltuk olacak (3 sol, 3 sağ)

                    for (int i = 1; i < siraSayisi; i++)
                    {
                        for (int j = 0; j < 6; j++) // Her satırda 6 koltuk dene (3 sol + 3 sağ)
                        {
                            if (arkaBesliMi == true)
                            {
                                if (i != sira - 1 && j == 2)
                                    continue;
                            }
                            else
                            {
                                if (j == 2) // Ortayı boş bırak (ara koridor
                                    continue;

                            }
                            if (j == 2) // Ortayı boş bırak (ara koridor)
                                continue;

                            Button koltuk = new Button();
                            koltuk.Height = koltuk.Width = 40;
                            koltuk.Top = 30 + (i * 45); // Satır pozisyonu
                            koltuk.Left = 5 + (j * 50); // Sütun pozisyonu (koltuklar arası boşluk için 50)
                            koltuk.Text = koltukNo.ToString();
                            koltukNo++;
                            koltuk.ContextMenuStrip = contextMenuStrip1;
                            koltuk.MouseDown += Koltuk_MouseDown;
                            this.Controls.Add(koltuk);
                            // this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
                            btnsil.Enabled = true; // Butonu etkinleştirir
                            btnsil.Visible = true; // Butonu görünür yapar */
                            BtnKoltukDegistir.Enabled = true;
                            BtnKoltukDegistir.Visible = true;
                            btncmbileseferekle.Enabled = true;
                            btncmbileseferekle.Visible = true;






                            if (koltukNo > toplamKoltukSayisi) // Koltuk sayısını aşmamak için kontrol
                                break;
                        }
                    }

                }
            }
        }
        Button tiklanan;

        private void Koltuk_MouseDown(object sender, MouseEventArgs e)
        {
            tiklanan = sender as Button;

        }

        private void rezerveEtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (cmbOtoSec.SelectedIndex == -1 || cmbKalkisİli.SelectedIndex == -1 || cmbvarisİli.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen gerekli alanları doldurunuz!");
                return;
            }
            if (tiklanan.BackColor == Color.Pink || tiklanan.BackColor == Color.Blue)
            {
                MessageBox.Show("Bu koltuk dolu,lütfen başka bir koltuk seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            KayitFormu2 kf = new KayitFormu2();
            DialogResult sonuc = kf.ShowDialog();
            if (sonuc == DialogResult.OK)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = String.Format("{0} {1}", kf.txtisim.Text, kf.txtsoyisim.Text);
                lvi.SubItems.Add(kf.mskdtelefon.Text);
                if (kf.chkkadın.Checked)
                {
                    lvi.SubItems.Add("KADIN");
                    tiklanan.BackColor = Color.Pink;

                }
                if (kf.ckbxerkek.Checked)
                {

                    lvi.SubItems.Add("ERKEK");
                    tiklanan.BackColor = Color.Blue;
                }
                lvi.SubItems.Add(cmbKalkisİli.Text);
                lvi.SubItems.Add(cmbvarisİli.Text);
                lvi.SubItems.Add(tiklanan.Text);
                lvi.SubItems.Add(dtmpsaat.Text);
                lvi.SubItems.Add(cmbOtoSec.Text);
                listView1.Items.Add(lvi);

                SaveDataToJson(); // Verileri otomatik kaydet

            }
        }



        private void btnsil_Click(object sender, EventArgs e)
        {
            // Hiçbir öğe seçilmemişse uyarı göster
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Lütfen silmek için bir satır seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Seçilen öğeleri kaldır
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                string koltukNo = item.SubItems[5].Text; // Koltuk numarasını al

                // Koltuğun rengini varsayılan hale getir
                foreach (Control ctrl in this.Controls)
                {
                    if (ctrl is Button && ctrl.Text == koltukNo)
                    {
                        ctrl.BackColor = default(Color); // Koltuğun rengini sıfırla
                        break;
                    }
                }

                // ListView'den öğeyi kaldır
                listView1.Items.Remove(item);
                SaveDataToJson(); // Verileri otomatik kaydet
            }

            // İşlem tamamlandıktan sonra bilgilendirme mesajı
            MessageBox.Show("Seçilen sefer başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnKoltukDegistir_Click(object sender, EventArgs e)
        {
            // ListView'de seçili bir öğe yoksa uyarı ver
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Lütfen değiştirmek için bir yolcu seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Seçilen yolcunun bilgilerini al
            ListViewItem secilenYolcu = listView1.SelectedItems[0];
            string eskiKoltukNo = secilenYolcu.SubItems[5].Text; // Eski koltuk numarası
            string cinsiyet = secilenYolcu.SubItems[2].Text; // Yolcunun cinsiyeti

            MessageBox.Show("Lütfen yeni bir koltuğa tıklayın.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Kullanıcının yeni koltuğa tıklamasını bekle
            Button yeniKoltuk = null;

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Button btn && btn.Text != eskiKoltukNo)
                {
                    btn.Click += YeniKoltukSecildi; // Yeni koltuk seçimi için olay bağlanıyor
                }
            }

            void YeniKoltukSecildi(object sender2, EventArgs e2)
            {
                yeniKoltuk = sender2 as Button;

                // Kullanıcıya onay mesajı
                DialogResult result = MessageBox.Show(
                    $"Yeni koltuk {yeniKoltuk.Text} olarak seçilsin mi?",
                    "Onay",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Eski koltuğun rengini sıfırla
                    foreach (Control ctrl in this.Controls)
                    {
                        if (ctrl is Button btn && btn.Text == eskiKoltukNo)
                        {
                            btn.BackColor = default(Color); // Eski koltuk rengini sıfırla
                            break;
                        }
                    }

                    // Yeni koltuğun rengini cinsiyete göre ayarla
                    if (cinsiyet == "KADIN")
                    {
                        yeniKoltuk.BackColor = Color.Pink;
                    }
                    else if (cinsiyet == "ERKEK")
                    {
                        yeniKoltuk.BackColor = Color.Blue;
                    }

                    // ListView'deki koltuk numarasını güncelle
                    secilenYolcu.SubItems[5].Text = yeniKoltuk.Text;
                    SaveDataToJson(); // Verileri otomatik kaydet

                    // Bilgilendirme mesajı
                    MessageBox.Show($"Koltuk değiştirildi. Yeni koltuk: {yeniKoltuk.Text}", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                // Tüm butonlardan olay bağlamasını kaldır
                foreach (Control ctrl in this.Controls)
                {
                    if (ctrl is Button btn)
                    {
                        btn.Click -= YeniKoltukSecildi;
                    }
                }


            }
        }




        private void cmbilekoltuksec_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ComboBox'tan seçilen koltuk numarasını al
            string secilenKoltukNo = cmbilekoltuksec.SelectedItem?.ToString();

            // Eğer ComboBox boş veya geçersiz bir değer seçildiyse
            if (string.IsNullOrEmpty(secilenKoltukNo))
            {
                MessageBox.Show("Lütfen geçerli bir koltuk seçiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Seçilen koltuk butonunu bul
            Button secilenKoltuk = null;

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Button && ctrl.Text == secilenKoltukNo)
                {
                    secilenKoltuk = (Button)ctrl;
                    break;
                }
            }

            // Eğer buton bulunamadıysa uyarı ver
            if (secilenKoltuk == null)
            {
                MessageBox.Show("Seçilen koltuk bulunamadı! Lütfen geçerli bir koltuk seçin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Eğer koltuk zaten rezerve edilmişse uyarı göster
            if (secilenKoltuk.BackColor == Color.Pink || secilenKoltuk.BackColor == Color.Blue)
            {
                MessageBox.Show("Bu koltuk dolu, lütfen başka bir koltuk seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Rezervasyon formunu aç
            KayitFormu2 kf = new KayitFormu2();
            DialogResult sonuc = kf.ShowDialog();

            if (sonuc == DialogResult.OK)
            {
                // Kullanıcı bilgilerini al ve kaydet
                ListViewItem lvi = new ListViewItem();
                lvi.Text = $"{kf.txtisim.Text} {kf.txtsoyisim.Text}";
                lvi.SubItems.Add(kf.mskdtelefon.Text);

                // Cinsiyete göre renk ayarla
                if (kf.chkkadın.Checked)
                {
                    lvi.SubItems.Add("KADIN");
                    secilenKoltuk.BackColor = Color.Pink;
                }
                else if (kf.ckbxerkek.Checked)
                {
                    lvi.SubItems.Add("ERKEK");
                    secilenKoltuk.BackColor = Color.Blue;
                }

                // Ek bilgiler
                lvi.SubItems.Add(cmbKalkisİli.Text);
                lvi.SubItems.Add(cmbvarisİli.Text);
                lvi.SubItems.Add(secilenKoltuk.Text);
                lvi.SubItems.Add(dtmpsaat.Text);
                lvi.SubItems.Add(cmbOtoSec.Text);
                // ListView'e ekle
                listView1.Items.Add(lvi);
                SaveDataToJson(); // Verileri otomatik kaydet

                MessageBox.Show("Rezervasyon başarılı!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //SaveDataToJson(); // Verileri otomatik kaydet
            }
        }

        private void btncmbileseferekle_Click(object sender, EventArgs e)
        {
            // ComboBox'tan seçim kontrolü
            string seciminiz = cmbdeneme.SelectedItem?.ToString()?.Trim();

            if (string.IsNullOrWhiteSpace(seciminiz))
            {
                MessageBox.Show("Lütfen geçerli bir koltuk seçiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Seçimin ListView'de olup olmadığını kontrol et
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.SubItems[4].Text == seciminiz) // 4. sütun (koltuk adı)
                {
                    MessageBox.Show("Bu koltuk dolu, lütfen başka bir koltuk seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            // Koltuk eşleşmesi: Koltuk butonlarını kontrol et
            bool koltukBulundu = false;

            foreach (Button koltukButonu in this.Controls.OfType<Button>())

            {
                if (koltukButonu.Text == "SEFER EKLE" || koltukButonu.Text == "KOLTUK DEĞİŞTİR" || koltukButonu.Text == "SEFER SİL")
                {
                    continue; // Bu butonları atla
                }
                // Koltuğun Text değeri ComboBox seçimiyle eşleşiyor mu?
                if (koltukButonu.Text == seciminiz)
                {
                    koltukBulundu = true;

                    // Koltuğun arka plan rengini kontrol et (mavi veya pembe ise)
                    if (koltukButonu.BackColor == Color.Blue || koltukButonu.BackColor == Color.Pink)
                    {
                        MessageBox.Show("Bu koltuk dolu, lütfen başka bir koltuk seçiniz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    koltukButonu.BackColor = Color.Yellow; // Seçilen koltuğu işaretle
                }
                else
                {
                    koltukButonu.BackColor = default(Color); // Diğerlerini varsayılan renge çevir
                }
            }

            if (!koltukBulundu)
            {
                MessageBox.Show("Seçilen koltuk bulunamadı. Lütfen geçerli bir seçim yapınız.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Rezervasyon formunu aç
            KayitFormu2 kf = new KayitFormu2();
            DialogResult sonuc = kf.ShowDialog();

            if (sonuc == DialogResult.OK)
            {
                // Kullanıcı bilgilerini al ve kaydet
                ListViewItem lvi = new ListViewItem
                {
                    Text = $"{kf.txtisim.Text} {kf.txtsoyisim.Text}"
                };
                lvi.SubItems.Add(kf.mskdtelefon.Text);
                lvi.SubItems.Add(cmbKalkisİli.Text);
                lvi.SubItems.Add(cmbvarisİli.Text);
                lvi.SubItems.Add(seciminiz); // Seçimi kaydet
                lvi.SubItems.Add(dtmpsaat.Text);

                // ListView'e ekle
                listView1.Items.Add(lvi);
                SaveDataToJson(); // Verileri otomatik kaydet

                MessageBox.Show("Rezervasyon başarılı!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        
    }

}




