﻿namespace BiletSatisiOtomasyonu
{
    partial class KayitFormu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtisim = new System.Windows.Forms.TextBox();
            this.mskdtelefon = new System.Windows.Forms.MaskedTextBox();
            this.btniptal = new System.Windows.Forms.Button();
            this.txtsoyisim = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btntamam = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1kadın = new System.Windows.Forms.CheckBox();
            this.checkBox2erkek = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "İsim";
            // 
            // txtisim
            // 
            this.txtisim.Location = new System.Drawing.Point(143, 43);
            this.txtisim.Name = "txtisim";
            this.txtisim.Size = new System.Drawing.Size(150, 23);
            this.txtisim.TabIndex = 1;
            // 
            // mskdtelefon
            // 
            this.mskdtelefon.Location = new System.Drawing.Point(143, 144);
            this.mskdtelefon.Mask = "(999) 000-0000";
            this.mskdtelefon.Name = "mskdtelefon";
            this.mskdtelefon.Size = new System.Drawing.Size(150, 23);
            this.mskdtelefon.TabIndex = 2;
            this.mskdtelefon.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // btniptal
            // 
            this.btniptal.Location = new System.Drawing.Point(48, 274);
            this.btniptal.Name = "btniptal";
            this.btniptal.Size = new System.Drawing.Size(84, 35);
            this.btniptal.TabIndex = 4;
            this.btniptal.Text = "İptal Et";
            this.btniptal.UseVisualStyleBackColor = true;
            // 
            // txtsoyisim
            // 
            this.txtsoyisim.AutoSize = true;
            this.txtsoyisim.Location = new System.Drawing.Point(45, 96);
            this.txtsoyisim.Name = "txtsoyisim";
            this.txtsoyisim.Size = new System.Drawing.Size(63, 16);
            this.txtsoyisim.TabIndex = 5;
            this.txtsoyisim.Text = "Soyisim";
            this.txtsoyisim.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "Telefon";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(143, 89);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(150, 23);
            this.textBox2.TabIndex = 7;
            // 
            // btntamam
            // 
            this.btntamam.Location = new System.Drawing.Point(178, 274);
            this.btntamam.Name = "btntamam";
            this.btntamam.Size = new System.Drawing.Size(90, 35);
            this.btntamam.TabIndex = 9;
            this.btntamam.Text = "Tamam";
            this.btntamam.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 200);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "Cinsiyet";
            // 
            // checkBox1kadın
            // 
            this.checkBox1kadın.AutoSize = true;
            this.checkBox1kadın.Location = new System.Drawing.Point(143, 200);
            this.checkBox1kadın.Name = "checkBox1kadın";
            this.checkBox1kadın.Size = new System.Drawing.Size(74, 20);
            this.checkBox1kadın.TabIndex = 11;
            this.checkBox1kadın.Text = "KADIN";
            this.checkBox1kadın.UseVisualStyleBackColor = true;
            // 
            // checkBox2erkek
            // 
            this.checkBox2erkek.AutoSize = true;
            this.checkBox2erkek.Location = new System.Drawing.Point(232, 200);
            this.checkBox2erkek.Name = "checkBox2erkek";
            this.checkBox2erkek.Size = new System.Drawing.Size(74, 20);
            this.checkBox2erkek.TabIndex = 12;
            this.checkBox2erkek.Text = "ERKEK";
            this.checkBox2erkek.UseVisualStyleBackColor = true;
            // 
            // KayitFormu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(375, 448);
            this.Controls.Add(this.checkBox2erkek);
            this.Controls.Add(this.checkBox1kadın);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btntamam);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtsoyisim);
            this.Controls.Add(this.btniptal);
            this.Controls.Add(this.mskdtelefon);
            this.Controls.Add(this.txtisim);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("MS Reference Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "KayitFormu";
            this.Text = "KayitFormu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtisim;
        private System.Windows.Forms.MaskedTextBox mskdtelefon;
        private System.Windows.Forms.Button btniptal;
        private System.Windows.Forms.Label txtsoyisim;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btntamam;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox1kadın;
        private System.Windows.Forms.CheckBox checkBox2erkek;
    }
}