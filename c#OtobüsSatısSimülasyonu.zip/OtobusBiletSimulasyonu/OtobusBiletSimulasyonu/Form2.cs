﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OtobusBiletSimulasyonu
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.dataGridView1.CellContentClick += dataGridView1_CellContentClick;
        }


        public void LoadPassengerData(List<ListViewItem> passengers)
        {
            // DataGridView'e kolon ekleme
            if (dataGridView1.Columns.Count == 0)
            {
                dataGridView1.Columns.Add("Sefer", "Sefer");
                dataGridView1.Columns.Add("YolcuAdSoyad", "Yolcu Ad Soyad");
                dataGridView1.Columns.Add("Telefon", "Telefon");
                dataGridView1.Columns.Add("Cinsiyet", "Cinsiyet");
                dataGridView1.Columns.Add("KoltukNo", "Koltuk No");
            }

            // Yolcu bilgilerini DataGridView'e ekleme
            dataGridView1.Rows.Clear();
            foreach (var item in passengers)
            {
                dataGridView1.Rows.Add(
                    item.SubItems[3].Text,  // Sefer (Kalkış İli)
                    item.Text,             // Yolcu Ad Soyad
                    item.SubItems[1].Text, // Telefon
                    item.SubItems[2].Text, // Cinsiyet
                    item.SubItems[5].Text  // Koltuk No
                );
            }
        }

        // DataGridView CellContentClick olayını işlemek için kullanılan metot
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Bu metodu boş bırakabilir ya da işlev ekleyebilirsiniz.
            MessageBox.Show($"Seçilen hücre: Satır {e.RowIndex}, Sütun {e.ColumnIndex}");
        }
    }
}
