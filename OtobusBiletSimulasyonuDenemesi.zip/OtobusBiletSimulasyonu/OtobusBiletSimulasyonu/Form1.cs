﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OtobusBiletSimulasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cmbOtoSec_SelectedIndexChanged(object sender, EventArgs e)
        {

            switch (cmbOtoSec.Text)
            {
                case "Pamukkale-01":
                    KoltukDoldur(12, true);
                    break;
                case "Kamil Koç-02":
                    KoltukDoldur(12, true);
                    break;
                case "Artvin Lüks-03":
                    KoltukDoldur(12, true);
                    break;
                case "yalova seyahat-04":
                    KoltukDoldur(12, true);
                    break;
                case "Mardin Seyahat-05":
                    KoltukDoldur(8, true);
                    break;
                case "Kontur-06":
                    KoltukDoldur(8, true);
                    break;
                case "Öz Sivas-07":
                    KoltukDoldur(8, true);
                    break;
                case "Nilüfer-08":
                    KoltukDoldur(8, true);
                    break;
                case "Artvin-09":
                    KoltukDoldur(8, true);
                    break;
                case "Uludağ turizm-10":
                    KoltukDoldur(8, true);
                    break;


            }
            void KoltukDoldur(int sira, bool arkaBesliMi)

            {
                foreach (Control ctrl in this.Controls)
                {
                    if (ctrl is Button)
                    {
                        Button btn = ctrl as Button;
                        if (btn.Text == "Kaydet")
                        {
                            continue;

                        }
                        else
                        {
                            this.Controls.Remove(ctrl);
                        }

                    }
                    int koltukNo = 1;
                    int toplamKoltukSayisi = 42;
                    int siraSayisi = toplamKoltukSayisi / 4; // Her satırda 6 koltuk olacak (3 sol, 3 sağ)

                    for (int i = 1; i < siraSayisi; i++)
                    {
                        for (int j = 0; j < 6; j++) // Her satırda 6 koltuk dene (3 sol + 3 sağ)
                        {
                            if (arkaBesliMi == true)
                            {
                                if (i != sira - 1 && j == 2)
                                    continue;
                            }
                            else
                            {
                                if (j == 2) // Ortayı boş bırak (ara koridor
                                    continue;

                            }
                            if (j == 2) // Ortayı boş bırak (ara koridor)
                                continue;

                            Button koltuk = new Button();
                            koltuk.Height = koltuk.Width = 40;
                            koltuk.Top = 30 + (i * 45); // Satır pozisyonu
                            koltuk.Left = 5 + (j * 50); // Sütun pozisyonu (koltuklar arası boşluk için 50)
                            koltuk.Text = koltukNo.ToString();
                            koltukNo++;
                           // koltuk.ContextMenuStrip = contextMenuStrip1;
                            this.Controls.Add(koltuk);

                            if (koltukNo > toplamKoltukSayisi) // Koltuk sayısını aşmamak için kontrol
                                break;
                        }
                    }

                }
            }
        }
    }
}
           
