﻿namespace OtobusBiletSimulasyonu
{
    partial class KayitFormu2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblisim = new System.Windows.Forms.Label();
            this.txtisim = new System.Windows.Forms.TextBox();
            this.mskdtelefon = new System.Windows.Forms.MaskedTextBox();
            this.ckbxerkek = new System.Windows.Forms.CheckBox();
            this.btniptal = new System.Windows.Forms.Button();
            this.txtsoyisim = new System.Windows.Forms.TextBox();
            this.lblsoyisim = new System.Windows.Forms.Label();
            this.lbltelefon = new System.Windows.Forms.Label();
            this.chkkadın = new System.Windows.Forms.CheckBox();
            this.btntamm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblisim
            // 
            this.lblisim.AutoSize = true;
            this.lblisim.Location = new System.Drawing.Point(64, 68);
            this.lblisim.Name = "lblisim";
            this.lblisim.Size = new System.Drawing.Size(31, 16);
            this.lblisim.TabIndex = 0;
            this.lblisim.Text = "İsim";
            // 
            // txtisim
            // 
            this.txtisim.Location = new System.Drawing.Point(158, 65);
            this.txtisim.Name = "txtisim";
            this.txtisim.Size = new System.Drawing.Size(138, 22);
            this.txtisim.TabIndex = 1;
            // 
            // mskdtelefon
            // 
            this.mskdtelefon.Location = new System.Drawing.Point(158, 202);
            this.mskdtelefon.Mask = "(999) 000-0000";
            this.mskdtelefon.Name = "mskdtelefon";
            this.mskdtelefon.Size = new System.Drawing.Size(138, 22);
            this.mskdtelefon.TabIndex = 2;
            // 
            // ckbxerkek
            // 
            this.ckbxerkek.AutoSize = true;
            this.ckbxerkek.Location = new System.Drawing.Point(185, 280);
            this.ckbxerkek.Name = "ckbxerkek";
            this.ckbxerkek.Size = new System.Drawing.Size(73, 20);
            this.ckbxerkek.TabIndex = 3;
            this.ckbxerkek.Text = "ERKEK";
            this.ckbxerkek.UseVisualStyleBackColor = true;
            // 
            // btniptal
            // 
            this.btniptal.Location = new System.Drawing.Point(67, 332);
            this.btniptal.Name = "btniptal";
            this.btniptal.Size = new System.Drawing.Size(75, 23);
            this.btniptal.TabIndex = 4;
            this.btniptal.Text = "İPTAL";
            this.btniptal.UseVisualStyleBackColor = true;
            this.btniptal.Click += new System.EventHandler(this.btniptal_Click);
            // 
            // txtsoyisim
            // 
            this.txtsoyisim.Location = new System.Drawing.Point(158, 124);
            this.txtsoyisim.Name = "txtsoyisim";
            this.txtsoyisim.Size = new System.Drawing.Size(138, 22);
            this.txtsoyisim.TabIndex = 6;
            // 
            // lblsoyisim
            // 
            this.lblsoyisim.AutoSize = true;
            this.lblsoyisim.Location = new System.Drawing.Point(64, 127);
            this.lblsoyisim.Name = "lblsoyisim";
            this.lblsoyisim.Size = new System.Drawing.Size(55, 16);
            this.lblsoyisim.TabIndex = 5;
            this.lblsoyisim.Text = "Soyisim";
            // 
            // lbltelefon
            // 
            this.lbltelefon.AutoSize = true;
            this.lbltelefon.Location = new System.Drawing.Point(64, 208);
            this.lbltelefon.Name = "lbltelefon";
            this.lbltelefon.Size = new System.Drawing.Size(53, 16);
            this.lbltelefon.TabIndex = 7;
            this.lbltelefon.Text = "Telefon";
            // 
            // chkkadın
            // 
            this.chkkadın.AutoSize = true;
            this.chkkadın.Location = new System.Drawing.Point(73, 280);
            this.chkkadın.Name = "chkkadın";
            this.chkkadın.Size = new System.Drawing.Size(69, 20);
            this.chkkadın.TabIndex = 8;
            this.chkkadın.Text = "KADIN";
            this.chkkadın.UseVisualStyleBackColor = true;
            // 
            // btntamm
            // 
            this.btntamm.Location = new System.Drawing.Point(183, 332);
            this.btntamm.Name = "btntamm";
            this.btntamm.Size = new System.Drawing.Size(75, 23);
            this.btntamm.TabIndex = 9;
            this.btntamm.Text = "TAMAM";
            this.btntamm.UseVisualStyleBackColor = true;
            this.btntamm.Click += new System.EventHandler(this.btntamm_Click);
            // 
            // KayitFormu2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 509);
            this.Controls.Add(this.btntamm);
            this.Controls.Add(this.chkkadın);
            this.Controls.Add(this.lbltelefon);
            this.Controls.Add(this.txtsoyisim);
            this.Controls.Add(this.lblsoyisim);
            this.Controls.Add(this.btniptal);
            this.Controls.Add(this.ckbxerkek);
            this.Controls.Add(this.mskdtelefon);
            this.Controls.Add(this.txtisim);
            this.Controls.Add(this.lblisim);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "KayitFormu2";
            this.Text = "KayitFormu2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblisim;
        private System.Windows.Forms.Button btniptal;
        private System.Windows.Forms.Label lblsoyisim;
        private System.Windows.Forms.Label lbltelefon;
        private System.Windows.Forms.Button btntamm;
        public System.Windows.Forms.TextBox txtisim;
        public System.Windows.Forms.MaskedTextBox mskdtelefon;
        public System.Windows.Forms.CheckBox ckbxerkek;
        public System.Windows.Forms.TextBox txtsoyisim;
        public System.Windows.Forms.CheckBox chkkadın;
    }
}