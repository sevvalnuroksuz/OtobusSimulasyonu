﻿namespace OtobusBiletSimulasyonu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OtobusSecme = new System.Windows.Forms.Label();
            this.cmbOtoSec = new System.Windows.Forms.ComboBox();
            this.lblKalkisİli = new System.Windows.Forms.Label();
            this.cmbKalkisİli = new System.Windows.Forms.ComboBox();
            this.cmbvarisİli = new System.Windows.Forms.ComboBox();
            this.lblVarisİli = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtmpsaat = new System.Windows.Forms.DateTimePicker();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnSeferiKaydet = new System.Windows.Forms.Button();
            this.groupBox1Sehirsec = new System.Windows.Forms.GroupBox();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1Sehirsec.SuspendLayout();
            this.SuspendLayout();
            // 
            // OtobusSecme
            // 
            this.OtobusSecme.AutoSize = true;
            this.OtobusSecme.Location = new System.Drawing.Point(370, 62);
            this.OtobusSecme.Name = "OtobusSecme";
            this.OtobusSecme.Size = new System.Drawing.Size(152, 16);
            this.OtobusSecme.TabIndex = 0;
            this.OtobusSecme.Text = "Otobus numarası seçiniz";
            // 
            // cmbOtoSec
            // 
            this.cmbOtoSec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOtoSec.FormattingEnabled = true;
            this.cmbOtoSec.Items.AddRange(new object[] {
            "Pamukkale-01",
            "Kamil Koç-02",
            "Artvin Lüks-03",
            "yalova seyahat-04",
            "Mardin Seyahat-05",
            "Kontur-06",
            "Öz Sivas-07",
            "Nilüfer-08",
            "Artvin-09",
            "Uludağ turizm-10"});
            this.cmbOtoSec.Location = new System.Drawing.Point(552, 54);
            this.cmbOtoSec.Name = "cmbOtoSec";
            this.cmbOtoSec.Size = new System.Drawing.Size(121, 24);
            this.cmbOtoSec.TabIndex = 1;
            this.cmbOtoSec.SelectedIndexChanged += new System.EventHandler(this.cmbOtoSec_SelectedIndexChanged);
            // 
            // lblKalkisİli
            // 
            this.lblKalkisİli.AutoSize = true;
            this.lblKalkisİli.Location = new System.Drawing.Point(10, 29);
            this.lblKalkisİli.Name = "lblKalkisİli";
            this.lblKalkisİli.Size = new System.Drawing.Size(55, 16);
            this.lblKalkisİli.TabIndex = 2;
            this.lblKalkisİli.Text = "Kalkış İli";
            // 
            // cmbKalkisİli
            // 
            this.cmbKalkisİli.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKalkisİli.FormattingEnabled = true;
            this.cmbKalkisİli.Items.AddRange(new object[] {
            " Adana",
            " Adıyaman",
            " Afyonkarahisar",
            " Ağrı",
            " Aksaray",
            " Amasya",
            " Ankara",
            " Antalya",
            " Ardahan",
            " Artvin",
            " Aydın",
            " Balıkesir",
            " Bartın",
            " Batman",
            " Bayburt",
            " Bilecik",
            " Bingöl",
            " Bitlis",
            " Bolu",
            " Burdur",
            " Bursa",
            " Çanakkale",
            " Çankırı",
            " Çorum",
            " Denizli",
            " Diyarbakır",
            " Düzce",
            " Edirne",
            " Elazığ",
            " Erzincan",
            " Erzurum",
            " Eskişehir",
            " Gaziantep",
            " Giresun",
            " Gümüşhane",
            " Hakkâri",
            " Hatay",
            " Iğdır",
            " Isparta",
            " İstanbul",
            " İzmir",
            " Kahramanmaraş",
            " Karabük",
            " Karaman",
            " Kars",
            " Kastamonu",
            " Kayseri",
            " Kilis",
            " Kırıkkale",
            " Kırklareli",
            " Kırşehir",
            " Kocaeli",
            " Konya",
            " Kütahya",
            " Malatya",
            " Manisa",
            " Mardin",
            " Mersin",
            " Muğla",
            " Muş",
            " Nevşehir",
            " Niğde",
            " Ordu",
            " Osmaniye",
            " Rize",
            " Sakarya",
            " Samsun",
            " Şanlıurfa",
            " Siirt",
            " Sinop",
            " Sivas",
            " Şırnak",
            " Tekirdağ",
            " Tokat",
            " Trabzon",
            " Tunceli",
            " Uşak",
            " Van",
            " Yalova",
            " Yozgat",
            " Zonguldak"});
            this.cmbKalkisİli.Location = new System.Drawing.Point(192, 21);
            this.cmbKalkisİli.Name = "cmbKalkisİli";
            this.cmbKalkisİli.Size = new System.Drawing.Size(121, 24);
            this.cmbKalkisİli.TabIndex = 3;
            // 
            // cmbvarisİli
            // 
            this.cmbvarisİli.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbvarisİli.FormattingEnabled = true;
            this.cmbvarisİli.Items.AddRange(new object[] {
            " Adana",
            " Adıyaman",
            " Afyonkarahisar",
            " Ağrı",
            " Aksaray",
            " Amasya",
            " Ankara",
            " Antalya",
            " Ardahan",
            " Artvin",
            " Aydın",
            " Balıkesir",
            " Bartın",
            " Batman",
            " Bayburt",
            " Bilecik",
            " Bingöl",
            " Bitlis",
            " Bolu",
            " Burdur",
            " Bursa",
            " Çanakkale",
            " Çankırı",
            " Çorum",
            " Denizli",
            " Diyarbakır",
            " Düzce",
            " Edirne",
            " Elazığ",
            " Erzincan",
            " Erzurum",
            " Eskişehir",
            " Gaziantep",
            " Giresun",
            " Gümüşhane",
            " Hakkâri",
            " Hatay",
            " Iğdır",
            " Isparta",
            " İstanbul",
            " İzmir",
            " Kahramanmaraş",
            " Karabük",
            " Karaman",
            " Kars",
            " Kastamonu",
            " Kayseri",
            " Kilis",
            " Kırıkkale",
            " Kırklareli",
            " Kırşehir",
            " Kocaeli",
            " Konya",
            " Kütahya",
            " Malatya",
            " Manisa",
            " Mardin",
            " Mersin",
            " Muğla",
            " Muş",
            " Nevşehir",
            " Niğde",
            " Ordu",
            " Osmaniye",
            " Rize",
            " Sakarya",
            " Samsun",
            " Şanlıurfa",
            " Siirt",
            " Sinop",
            " Sivas",
            " Şırnak",
            " Tekirdağ",
            " Tokat",
            " Trabzon",
            " Tunceli",
            " Uşak",
            " Van",
            " Yalova",
            " Yozgat",
            " Zonguldak"});
            this.cmbvarisİli.Location = new System.Drawing.Point(192, 87);
            this.cmbvarisİli.Name = "cmbvarisİli";
            this.cmbvarisİli.Size = new System.Drawing.Size(121, 24);
            this.cmbvarisİli.TabIndex = 4;
            // 
            // lblVarisİli
            // 
            this.lblVarisİli.AutoSize = true;
            this.lblVarisİli.Location = new System.Drawing.Point(10, 87);
            this.lblVarisİli.Name = "lblVarisİli";
            this.lblVarisİli.Size = new System.Drawing.Size(53, 16);
            this.lblVarisİli.TabIndex = 5;
            this.lblVarisİli.Text = "Varış ili ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(370, 282);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Tarih Seç";
            // 
            // dtmpsaat
            // 
            this.dtmpsaat.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtmpsaat.Location = new System.Drawing.Point(552, 276);
            this.dtmpsaat.Name = "dtmpsaat";
            this.dtmpsaat.Size = new System.Drawing.Size(200, 22);
            this.dtmpsaat.TabIndex = 7;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(881, 33);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(578, 550);
            this.listView1.TabIndex = 8;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // btnSeferiKaydet
            // 
            this.btnSeferiKaydet.Location = new System.Drawing.Point(493, 359);
            this.btnSeferiKaydet.Name = "btnSeferiKaydet";
            this.btnSeferiKaydet.Size = new System.Drawing.Size(101, 36);
            this.btnSeferiKaydet.TabIndex = 9;
            this.btnSeferiKaydet.Text = "KAYDET";
            this.btnSeferiKaydet.UseVisualStyleBackColor = true;
            // 
            // groupBox1Sehirsec
            // 
            this.groupBox1Sehirsec.Controls.Add(this.cmbKalkisİli);
            this.groupBox1Sehirsec.Controls.Add(this.lblKalkisİli);
            this.groupBox1Sehirsec.Controls.Add(this.cmbvarisİli);
            this.groupBox1Sehirsec.Controls.Add(this.lblVarisİli);
            this.groupBox1Sehirsec.Location = new System.Drawing.Point(373, 102);
            this.groupBox1Sehirsec.Name = "groupBox1Sehirsec";
            this.groupBox1Sehirsec.Size = new System.Drawing.Size(346, 148);
            this.groupBox1Sehirsec.TabIndex = 10;
            this.groupBox1Sehirsec.TabStop = false;
            this.groupBox1Sehirsec.Text = "Şehir Seç";
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "YOLCU";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Telefon";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Cinsiyet";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Kalkış İli";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Varış İli";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Koltuk No";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Tarih";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1490, 619);
            this.Controls.Add(this.groupBox1Sehirsec);
            this.Controls.Add(this.btnSeferiKaydet);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.dtmpsaat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbOtoSec);
            this.Controls.Add(this.OtobusSecme);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1Sehirsec.ResumeLayout(false);
            this.groupBox1Sehirsec.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OtobusSecme;
        private System.Windows.Forms.ComboBox cmbOtoSec;
        private System.Windows.Forms.Label lblKalkisİli;
        private System.Windows.Forms.ComboBox cmbKalkisİli;
        private System.Windows.Forms.ComboBox cmbvarisİli;
        private System.Windows.Forms.Label lblVarisİli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtmpsaat;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnSeferiKaydet;
        private System.Windows.Forms.GroupBox groupBox1Sehirsec;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
    }
}

